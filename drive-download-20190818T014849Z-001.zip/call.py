import chrome
import falkon
import firefox
import gnome
import palemoon
import slimjet
import whaterfox
import yandex
import time

url = 'https://fatalmodel.com/102380/mariah-mulata-vip/3572094'
typeMedia = 'foto'

firefox.startRequest(url,typeMedia)
time.sleep(318)
chrome.startRequest(url,typeMedia)
time.sleep(493)
falkon.startRequest(url,typeMedia)
time.sleep(351)
gnome.startRequest(url,typeMedia)
time.sleep(369)
palemoon.startRequest(url,typeMedia)
time.sleep(398)
yandex.startRequest(url,typeMedia)
time.sleep(377)
slimjet.startRequest(url,typeMedia)
time.sleep(315)
whaterfox.startRequest(url,typeMedia)
